# Changelog

## v0.3.0
- Replaced demo-only UI with mobile-first authenticated client.
- Connected UI to auth, model catalog, chat, compare, and memory endpoints.
- Added PWA manifest, offline shell cache, Android app icons, and Capacitor instructions.
- Added API URL configuration for emulator and physical-device testing.
- Corrected chat endpoint mount from `/api/` to `/api/chat`.
- Preserved server-side provider API key configuration.

# Changelog

## 0.4.0
- Added GitHub Actions workflow to build a Capacitor Android debug APK in the cloud.
- Added Android preparation/build scripts.
- Added phone-only GitHub upload, cloud build, APK download, backend deployment, and troubleshooting instructions.
- Retained v0.3 backend and web app as the build base.
