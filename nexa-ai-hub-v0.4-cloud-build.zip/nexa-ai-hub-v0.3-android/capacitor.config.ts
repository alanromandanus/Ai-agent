import type { CapacitorConfig } from '@capacitor/cli';
const config: CapacitorConfig = {
  appId: 'com.nexaaihub.app',
  appName: 'NEXA AI HUB',
  webDir: 'web/public',
  bundledWebRuntime: false,
  android: { allowMixedContent: true }
};
export default config;
