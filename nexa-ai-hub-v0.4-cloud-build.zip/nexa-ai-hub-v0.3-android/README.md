# NEXA AI HUB v0.4 — Android Cloud Build Edition

Versi ini melanjutkan source v0.3 dan menambahkan workflow GitHub Actions untuk membangun **debug APK di cloud**. Pengguna cukup memakai HP Android untuk mengunggah source, menjalankan workflow, dan mengunduh hasil build.

## Isi v0.4
- Source web mobile-first/PWA dari v0.3.
- Backend Express + Prisma + PostgreSQL dari v0.3.
- Konfigurasi Capacitor Android.
- GitHub Actions workflow: `.github/workflows/android-debug-apk.yml`.
- Build APK otomatis ketika workflow dijalankan manual atau saat tag `v*` didorong.
- APK diunggah sebagai GitHub Actions artifact bernama `nexa-ai-hub-debug-apk`.

## Cara membuat APK hanya dengan HP Android

### A. Buat repository GitHub
1. Buka https://github.com di Chrome Android dan masuk/daftar.
2. Buat repository baru, misalnya `nexa-ai-hub`, pilih **Private** jika source belum ingin dipublikasikan.
3. Ekstrak ZIP v0.4 menggunakan aplikasi Files/Manajer File Android.
4. Unggah isi folder proyek ke repository dengan fitur **Add file → Upload files** pada GitHub versi web. Pastikan folder `.github/workflows` ikut terunggah. Jika GitHub mobile tidak menampilkan file/folder tersembunyi, gunakan browser dengan opsi **Situs desktop** dan pastikan workflow ikut terunggah.

### B. Jalankan Cloud Build
1. Buka tab **Actions** pada repository.
2. Jika diminta, aktifkan GitHub Actions.
3. Pilih workflow **Build NEXA AI HUB Android APK**.
4. Tekan **Run workflow**.
5. Tunggu sampai proses selesai dengan status hijau.
6. Buka hasil run, cari bagian **Artifacts**, lalu unduh `nexa-ai-hub-debug-apk`.
7. Ekstrak file artifact ZIP di HP. Di dalamnya ada `app-debug.apk`.
8. Buka APK dan izinkan pemasangan dari sumber tersebut bila Android meminta izin.

## Penting: APK debug vs aplikasi yang benar-benar online

APK debug adalah paket untuk uji instalasi dan tampilan. Agar login, chat, model, dan memori bekerja, backend harus sudah dideploy ke server HTTPS dengan PostgreSQL dan konfigurasi provider AI. Jangan memakai `localhost` atau `10.0.2.2` untuk server produksi. Masukkan URL backend HTTPS yang sebenarnya di layar login/pengaturan aplikasi.

API key provider harus berada di environment server, tidak boleh dimasukkan ke aplikasi Android atau repository.

## Backend (deployment terpisah)
1. Deploy folder `backend` pada hosting Node.js yang mendukung Node 20+.
2. Siapkan PostgreSQL terkelola.
3. Atur variabel dari `backend/.env.example`, termasuk `DATABASE_URL`, `JWT_SECRET`, `OPENROUTER_API_KEY`, `CORS_ORIGIN`, dan `NEXA_ALLOWED_MODELS`.
4. Jalankan `npm run db:generate` dan migrasi database sesuai prosedur proyek.
5. Pastikan `GET /health` merespons melalui HTTPS.
6. Gunakan URL tersebut pada aplikasi Android.

## Batasan dan keamanan
- Workflow menghasilkan **debug APK**, bukan APK rilis Play Store.
- Debug APK tidak memakai signing key produksi.
- Untuk rilis publik dibutuhkan signing key/keystore yang dibuat dan disimpan privat, kebijakan privasi, verifikasi email, reset password, kuota/biaya, monitoring, backup, serta pengujian keamanan.
- Jangan pernah commit `.env`, API key, password database, JWT secret, atau keystore ke GitHub.
- Source v0.3 masih merupakan starter kit. Integrasi API dan backend perlu diuji setelah backend dideploy; cloud build APK saja tidak membuktikan semua fitur AI sudah berfungsi.
- Jika upload melalui HP sulit, gunakan PWA yang di-host HTTPS untuk uji awal UI. PWA tidak sama dengan APK native.

## Troubleshooting
- **Workflow tidak muncul:** pastikan file `.github/workflows/android-debug-apk.yml` ada pada branch default.
- **Build gagal karena Gradle/Java:** buka log job dan periksa langkah yang gagal; workflow memakai Java 17 dan Node 20.
- **APK terpasang tetapi tidak bisa login:** backend belum online, URL API salah, CORS belum mengizinkan domain, atau HTTPS/certificate bermasalah.
- **Model tidak tersedia:** periksa API key dan daftar model yang diizinkan pada backend.
