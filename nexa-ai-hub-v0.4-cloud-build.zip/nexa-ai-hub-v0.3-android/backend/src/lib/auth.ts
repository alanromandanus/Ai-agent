import type { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';

export interface AuthRequest extends Request { userId?: string }
const secret = process.env.JWT_SECRET;
if (!secret || secret.length < 32) throw new Error('JWT_SECRET wajib diisi dengan minimal 32 karakter.');
export function signToken(userId: string) { return jwt.sign({ sub: userId }, secret!, { expiresIn: '7d' }); }
export function requireAuth(req: AuthRequest, res: Response, next: NextFunction) {
  const token = req.header('authorization')?.replace(/^Bearer\s+/i, '');
  if (!token) return res.status(401).json({ error: 'AUTH_REQUIRED' });
  try {
    const payload = jwt.verify(token, secret!) as jwt.JwtPayload;
    if (typeof payload.sub !== 'string') throw new Error('Invalid token');
    req.userId = payload.sub; next();
  } catch { return res.status(401).json({ error: 'INVALID_TOKEN' }); }
}
