export type ChatMessage = { role: 'system' | 'user' | 'assistant'; content: string };
export type ProviderResult = { text: string; inputTokens: number; outputTokens: number; provider: string };

const catalog = [
  { id: 'openai/gpt-4o-mini', name: 'GPT-4o mini', provider: 'OpenRouter', tier: 'fast' },
  { id: 'openai/gpt-4.1', name: 'GPT-4.1', provider: 'OpenRouter', tier: 'advanced' },
  { id: 'anthropic/claude-sonnet-4', name: 'Claude Sonnet', provider: 'OpenRouter', tier: 'advanced' },
  { id: 'google/gemini-2.5-flash', name: 'Gemini Flash', provider: 'OpenRouter', tier: 'fast' },
  { id: 'x-ai/grok-3-mini', name: 'Grok mini', provider: 'OpenRouter', tier: 'fast' }
];
export function listModels() {
  const configured = Boolean(process.env.OPENROUTER_API_KEY);
  return { models: catalog.map(m => ({ ...m, available: configured })), providers: [{ id: 'openrouter', configured }] };
}

export async function generate(model: string, messages: ChatMessage[]): Promise<ProviderResult> {
  const key = process.env.OPENROUTER_API_KEY;
  if (!key) throw Object.assign(new Error('OPENROUTER_API_KEY belum dikonfigurasi di server.'), { status: 503 });
  if (!/^[a-zA-Z0-9._-]+\/[a-zA-Z0-9._:-]+$/.test(model)) throw Object.assign(new Error('Model tidak valid.'), { status: 400 });
  const allowed = (process.env.NEXA_ALLOWED_MODELS || catalog.map(m => m.id).join(',')).split(',').map(x => x.trim()).filter(Boolean);
  if (!allowed.includes(model)) throw Object.assign(new Error('Model belum diaktifkan oleh administrator.'), { status: 403 });
  const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
    method: 'POST',
    headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json', 'HTTP-Referer': process.env.APP_URL || 'http://localhost:3000', 'X-Title': 'NEXA AI HUB' },
    body: JSON.stringify({ model, messages, temperature: 0.7, max_tokens: 1200 })
  });
  const data = await response.json().catch(() => ({})) as any;
  if (!response.ok) throw Object.assign(new Error(data?.error?.message || `Provider error (${response.status})`), { status: response.status === 429 ? 429 : 502 });
  const text = data?.choices?.[0]?.message?.content;
  if (typeof text !== 'string') throw Object.assign(new Error('Provider mengembalikan format jawaban yang tidak dikenal.'), { status: 502 });
  return { text, inputTokens: data.usage?.prompt_tokens ?? 0, outputTokens: data.usage?.completion_tokens ?? 0, provider: 'openrouter' };
}
