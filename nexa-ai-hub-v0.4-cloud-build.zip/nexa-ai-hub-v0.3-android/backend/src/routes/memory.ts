import { Router } from 'express';
import { z } from 'zod';
import { prisma } from '../lib/prisma.js';
import { requireAuth, type AuthRequest } from '../lib/auth.js';
const router = Router(); router.use(requireAuth);
router.get('/', async (req: AuthRequest, res, next) => { try { res.json({ memories: await prisma.memory.findMany({ where: { userId: req.userId! }, orderBy: { createdAt: 'desc' } }) }); } catch (e) { next(e); } });
router.post('/', async (req: AuthRequest, res, next) => {
  try { const p = z.object({ content: z.string().trim().min(1).max(4000), category: z.string().max(40).optional(), shareWithAI: z.boolean().default(false) }).safeParse(req.body); if (!p.success) return res.status(400).json({ error: 'INVALID_INPUT' }); const memory = await prisma.memory.create({ data: { ...p.data, userId: req.userId! } }); res.status(201).json({ memory }); } catch (e) { next(e); }
});
router.patch('/:id', async (req: AuthRequest, res, next) => {
  try { const p = z.object({ content: z.string().trim().min(1).max(4000).optional(), category: z.string().max(40).optional(), shareWithAI: z.boolean().optional() }).safeParse(req.body); if (!p.success) return res.status(400).json({ error: 'INVALID_INPUT' }); const result = await prisma.memory.updateMany({ where: { id: req.params.id, userId: req.userId! }, data: p.data }); if (!result.count) return res.status(404).json({ error: 'MEMORY_NOT_FOUND' }); const memory = await prisma.memory.findFirst({ where: { id: req.params.id, userId: req.userId! } }); res.json({ memory }); } catch (e) { next(e); }
});
router.delete('/:id', async (req: AuthRequest, res, next) => { try { const result = await prisma.memory.deleteMany({ where: { id: req.params.id, userId: req.userId! } }); if (!result.count) return res.status(404).json({ error: 'MEMORY_NOT_FOUND' }); res.status(204).end(); } catch (e) { next(e); } });
export default router;
