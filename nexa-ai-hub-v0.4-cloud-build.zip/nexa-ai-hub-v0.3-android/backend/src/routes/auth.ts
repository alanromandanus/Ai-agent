import { Router } from 'express';
import { z } from 'zod';
import bcrypt from 'bcryptjs';
import { prisma } from '../lib/prisma.js';
import { signToken, requireAuth, type AuthRequest } from '../lib/auth.js';
const router = Router();
const credentials = z.object({ email: z.email().max(254), password: z.string().min(10).max(72), displayName: z.string().trim().min(1).max(80).optional() });
router.post('/register', async (req, res, next) => {
  try {
    const parsed = credentials.safeParse(req.body); if (!parsed.success) return res.status(400).json({ error: 'INVALID_INPUT', details: parsed.error.flatten() });
    const { email, password, displayName } = parsed.data;
    const exists = await prisma.user.findUnique({ where: { email: email.toLowerCase() } });
    if (exists) return res.status(409).json({ error: 'EMAIL_EXISTS' });
    const user = await prisma.user.create({ data: { email: email.toLowerCase(), passwordHash: await bcrypt.hash(password, 12), displayName } });
    res.status(201).json({ token: signToken(user.id), user: { id: user.id, email: user.email, displayName: user.displayName, plan: user.plan } });
  } catch (e) { next(e); }
});
router.post('/login', async (req, res, next) => {
  try {
    const parsed = z.object({ email: z.email(), password: z.string().min(1) }).safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: 'INVALID_INPUT' });
    const user = await prisma.user.findUnique({ where: { email: parsed.data.email.toLowerCase() } });
    if (!user || !(await bcrypt.compare(parsed.data.password, user.passwordHash))) return res.status(401).json({ error: 'INVALID_CREDENTIALS' });
    res.json({ token: signToken(user.id), user: { id: user.id, email: user.email, displayName: user.displayName, plan: user.plan } });
  } catch (e) { next(e); }
});
router.get('/me', requireAuth, async (req: AuthRequest, res, next) => {
  try { const user = await prisma.user.findUnique({ where: { id: req.userId! }, select: { id: true, email: true, displayName: true, plan: true, createdAt: true } }); if (!user) return res.status(404).json({ error: 'USER_NOT_FOUND' }); res.json({ user }); } catch (e) { next(e); }
});
export default router;
