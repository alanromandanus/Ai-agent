import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import authRoutes from './routes/auth.js';
import memoryRoutes from './routes/memory.js';
import chatRoutes from './routes/chat.js';

const app = express();
app.disable('x-powered-by');
app.use(helmet());
const origins = (process.env.CORS_ORIGINS || 'http://localhost:3000,http://localhost:5173,capacitor://localhost,http://localhost').split(',').map(x => x.trim());
app.use(cors({ origin: (origin, cb) => { if (!origin || origins.includes(origin)) return cb(null, true); cb(new Error('Origin not allowed')); }, credentials: false }));
app.use(express.json({ limit: '1mb' }));
app.use('/api', rateLimit({ windowMs: 60_000, limit: 90, standardHeaders: 'draft-8', legacyHeaders: false }));
app.get('/health', (_req, res) => res.json({ ok: true, service: 'nexa-api', version: '0.3.0' }));
app.use('/api/auth', authRoutes);
app.use('/api/memories', memoryRoutes);
app.use('/api', chatRoutes);
app.use((err: any, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
  console.error(err?.message || err);
  const status = Number(err?.status) || 500;
  res.status(status).json({ error: status >= 500 ? 'SERVER_OR_PROVIDER_ERROR' : 'REQUEST_ERROR', message: process.env.NODE_ENV === 'production' && status >= 500 ? 'Terjadi kesalahan server.' : String(err?.message || 'Unknown error') });
});
const port = Number(process.env.PORT || 4000);
app.listen(port, () => console.log(`NEXA API listening on :${port}`));
