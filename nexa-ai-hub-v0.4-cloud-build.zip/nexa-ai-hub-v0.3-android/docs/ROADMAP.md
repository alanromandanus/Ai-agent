# NEXA AI HUB — build plan

## Phase 1 — API and persistence (starter included)
Auth, PostgreSQL schema, user-scoped memory, chat/compare gateway, usage logging.

## Phase 2 — Connect the user interface
Replace demo timers with API calls; add login/register, token lifecycle, conversation list, memory consent controls, error/loading states, and model catalog discovery.

## Phase 3 — Provider breadth
Keep OpenRouter as the broad initial catalog. Add direct adapters only where useful (OpenAI Responses, Anthropic Messages, Google GenAI, xAI) behind one normalized provider interface. Model list must be refreshed from provider metadata rather than assuming a fixed list.

## Phase 4 — Memory quality
Add embeddings + pgvector, source/provenance, user edit/delete/export, retention controls, and retrieval filters. Share only opted-in memories with the selected provider.

## Phase 5 — Android and business
Capacitor build, secure token storage, push/deep links, store signing; then quotas, subscription tiers, payment gateway and webhook reconciliation.
