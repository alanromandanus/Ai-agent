# Android test setup (Capacitor)

Aplikasi web mobile-first berada di `../web/public`. Identitas native ditentukan di `../capacitor.config.ts` (`com.nexaaihub.app`).

Persyaratan: Android Studio + Android SDK, JDK 17/21, Node.js 20+.

```bash
npm install
npx cap add android
npx cap sync android
npx cap open android
```

Untuk emulator lokal, aplikasi menggunakan API `http://10.0.2.2:4000`. Untuk HTTP development, tambahkan `android:usesCleartextTraffic="true"` pada `<application>` di `android/app/src/main/AndroidManifest.xml`. Jangan gunakan cleartext di produksi; deploy API HTTPS dan matikan izin tersebut.

Untuk HP fisik, set API URL pada Pengaturan aplikasi ke IP LAN komputer yang menjalankan backend. Untuk menguji tanpa membuat APK, deploy `web/public` ke HTTPS lalu pilih Install app dari Chrome Android.

APK belum dikompilasi atau ditandatangani dalam paket source ini. Buat debug APK melalui Android Studio: **Build → Build Bundle(s) / APK(s) → Build APK(s)**. Release build memerlukan signing key yang harus disimpan privat.
